﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace mypaint
{
    class FigurLinje : Bild
    {
        public FigurLinje()
        {
            this.färg = Color.Black;
            this.tjocklek = 5;
            this.Rektan = new Rectangle(0, 0, 30, 30);
        }
        public FigurLinje(Color color, float width, Point startPoint, Point endPoint)
        {
            this.färg = color;
            this.tjocklek = width;
            this.startPos = startPoint;
            this.slutPos = endPoint;
        }
    }
}
