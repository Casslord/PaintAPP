﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mypaint
{
    class FigurCirkel : Bild
    {
        List<Rectangle> rectangles = new List<Rectangle>();

        public FigurCirkel()
        {
            this.färg = Color.Black;
            this.tjocklek = 5;
            this.Rektan = new Rectangle(0, 0, 30, 30);
        }

        public FigurCirkel(Color color, float width, Rectangle rect)
        {
            this.färg = color;
            this.tjocklek = width;
            this.Rektan = rect;
        }

        //protected override void OnMouseUp(MouseEventArgs e)
        //{
        //    if (drawing)
        //    {
        //        drawing = false;
        //        var rc = getRectangle();
        //        if (rc.Width > 0 && rc.Height > 0) rectangles.Add(rc);
        //        this.Invalidate();
        //    }
        //}
        //protected override void OnPaint(PaintEventArgs e)
        //{
        //    if (rectangles.Count > 0)
        //    {
        //        foreach (Rectangle r in rectangles)
        //            e.Graphics.DrawEllipse(Pens.Red, r);
        //    }
        //    if (drawing) e.Graphics.DrawEllipse(Pens.Black, getRectangle());
        //}
    }
}