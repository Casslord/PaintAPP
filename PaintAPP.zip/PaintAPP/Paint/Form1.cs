﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace mypaint 
{
    public partial class Form1 : Form
    {
        FigurRektangel rekt;
        FigurCirkel cirk;
        Penna pen;

        ColorDialog MyDialog = new ColorDialog();
        public Color color;

        Figur tavla;

        public Form1()
        {
            InitializeComponent();

            tavla = new Figur(new Pen(Color.Black, 10), panel1.Location, panel1.Size);
            Controls.Add(tavla);



            panel1.Visible = false;
            panel1.Enabled = false;
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Rectangle_CheckedChanged(object sender, EventArgs e) { Kontroll(); }


        private void Circle_CheckedChanged(object sender, EventArgs e) { Kontroll(); }


        private void Pen1_CheckedChanged(object sender, EventArgs e) { Kontroll(); }
    

        private void btnColorPicker_Click(object sender, EventArgs e)
        {
            // Keeps the user from selecting a custom color.
            MyDialog.AllowFullOpen = false;
            // Allows the user to get help. (The default is false.)
            MyDialog.ShowHelp = true;
            
            // Update the text box color if the user clicks OK 
            if (MyDialog.ShowDialog() == DialogResult.OK)
            {
                color = MyDialog.Color;
            }

            textBox1.BackColor = MyDialog.Color;
            tavla.valdPensel.Color = color;

            
        }

        public void Kontroll()
        {
            if (Pen1.Checked == true)
                tavla.tillgänglig = true;
            else
                tavla.tillgänglig = false;

            if (Linje.Checked == true)
                tavla.valdFigur = new FigurLinje();
            if (Rectangle.Checked == true)
                tavla.valdFigur = new FigurRektangel();
            if (Circle.Checked == true)
                tavla.valdFigur = new FigurCirkel();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Linje_CheckedChanged(object sender, EventArgs e) { Kontroll(); }

        private void bindingNavigator1_RefreshItems(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            tavla.valdPensel.Width = (float)numericUpDown1.Value;
        }
    }
}
