﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace mypaint
{
    class Figur : Panel
    {
        private Rita fri = new Rita();
        //protected Color color;

        protected Point startPos;
        protected Point currentPos;
        protected bool drawing;
        
        public bool tillgänglig;
        public Bild valdFigur; 
        public Pen valdPensel;   
        public Bitmap bitmap;


        public List<Rectangle> figures = new List<Rectangle>();

        public Figur(Pen förvald, Point pos, Size storlek)
        {
            tillgänglig = true;  
            BackColor = Color.White;  
            this.Location = pos; 
            this.Size = storlek;  


            DoubleBuffered = true;


            valdPensel = förvald;

            valdPensel.StartCap = LineCap.Round;
            valdPensel.EndCap = LineCap.Round;
            
            SetStyle(ControlStyles.ResizeRedraw, true);
            valdFigur = new FigurRektangel(förvald.Color, förvald.Width, new Rectangle());
            
            bitmap = new Bitmap(this.Width, this.Height, this.CreateGraphics());

            Graphics.FromImage(bitmap).Clear(Color.White); 

        }

        protected Rectangle getRectangle()
        {
            return new Rectangle(
                Math.Min(startPos.X, currentPos.X),
                Math.Min(startPos.Y, currentPos.Y),
                Math.Abs(startPos.X - currentPos.X),
                Math.Abs(startPos.Y - currentPos.Y));
        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            currentPos = startPos = e.Location;
            drawing = true;

            if (tillgänglig)
            {
                fri.draw = true;  

                fri.position = e.Location;
            }

        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            currentPos = e.Location;

            if (drawing)
            {
                this.Invalidate();
            }
            
            if (tillgänglig)
            {
                if (fri.draw)
                {
                    Graphics graphics = Graphics.FromImage(bitmap);

                    graphics.DrawLine(valdPensel, fri.position.X, fri.position.Y, e.X, e.Y);
                }
                fri.position = e.Location;
                
            }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            drawing = false;
            currentPos = e.Location;

            Graphics g = Graphics.FromImage(bitmap);

            if (tillgänglig) { fri.draw = false; }
            else if (valdFigur is FigurLinje)
            {
                AddLine(g);
            }
            else if (valdFigur is FigurRektangel)
            {
                AddRectangle(g);
            }
            else if (valdFigur is FigurCirkel)
            {
                AddCircle(g);
            }


            this.Invalidate();
        }


        private void AddLine(Graphics g)
        {

            if (startPos.X - currentPos.X != 0 || startPos.Y - currentPos.Y != 0)
            {
                g.DrawLine(valdPensel, startPos, currentPos);
            }
        }

        private void AddRectangle(Graphics g)
        {
            var rc = getRectangle();
            if (rc.Width > 0 & rc.Height > 0)
            {g.DrawRectangle(valdPensel, rc);}
        }

        private void AddCircle(Graphics g)
        {
            var rc = getRectangle();
            if (rc.Width > 0 & rc.Height > 0)
            { g.DrawEllipse(valdPensel, rc); }
        }


        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.DrawImageUnscaled(bitmap, new Point(0, 0));

            if (drawing == true && tillgänglig == false)
            {
                if (valdFigur is FigurRektangel) { e.Graphics.DrawRectangle(Pens.Red, getRectangle()); }

                else if (valdFigur is FigurLinje) { e.Graphics.DrawLine(Pens.Red, startPos, currentPos); }

                else if (valdFigur is FigurCirkel) { e.Graphics.DrawEllipse(Pens.Red, getRectangle()); }    
            }

        }
    }
}
