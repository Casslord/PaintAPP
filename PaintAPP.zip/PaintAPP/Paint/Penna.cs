﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mypaint
{
    class Penna
    {

        Color color;


        int pX = -1;
        int pY = -1;

        Bitmap drawing;

        public Point position;
        public bool draw;
        
        public Penna()
        {
            position = new Point(-1, -1);
            draw = false;
        }

        public Penna(Color c)
        {
            //
            this.color = c;
            //

            
        }

    }
}
