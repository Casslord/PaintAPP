﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace mypaint
{
    abstract class Bild
    {
        public Color färg;
        public Point slutPos;

        public float tjocklek;

        public Point startPos;
        private Rectangle rektangel;
        public Rectangle Rektan
        {
            get
            {
                return this.rektangel;
            }

            set
            {
                this.rektangel = value;
                this.slutPos = new Point(value.X + value.Width, value.Y + value.Height);
                this.startPos = new Point(value.X, value.Y);
                
            }
        }
    }
}
