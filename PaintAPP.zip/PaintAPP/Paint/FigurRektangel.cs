﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace mypaint
{
    class FigurRektangel : Bild
    {
        //protected override void OnMouseUp(MouseEventArgs e)
        //{
        //    if (drawing)
        //    {
        //        drawing = false;
        //        var rc = getRectangle();
        //        if (rc.Width > 0 && rc.Height > 0) figures.Add(rc);
        //        this.Invalidate(); //ritar om fönstret
        //    }
        //}
        //protected override void OnPaint(PaintEventArgs e)
        //{
        //    if (figures.Count > 0) e.Graphics.DrawRectangles(Pens.Red, figures.ToArray());
        //    if (drawing) e.Graphics.DrawRectangle(Pens.Black, getRectangle());
        //}

        public FigurRektangel(Color color, float width, Rectangle rect)
        {
            this.färg = color;
            this.tjocklek = width;
            this.Rektan = rect;
        }

        public FigurRektangel()
        {
            this.färg = Color.Black;
            this.tjocklek = 5;
            this.Rektan = new Rectangle(0, 0, 30, 30);
        }
    }
}
